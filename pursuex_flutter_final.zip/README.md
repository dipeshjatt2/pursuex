
Pursuex Flutter + Chaquopy project (ready-to-build)

Important notes:
- This project skeleton embeds your Flask app under:
  android/app/src/main/python/pursuex
- Chaquopy plugin is referenced in android/app/build.gradle (skeleton). You must install Chaquopy and set up Gradle plugin properly.
- Open this project in Android Studio (File > Open) to resolve Gradle, Chaquopy, and SDK settings.
- The Java MainActivity includes Chaquopy initialization and attempts to run the Flask app.
- You must ensure Flask is installed in the embedded Python environment. In Chaquopy, you can use pip to include 'flask'. Configure chaquopy.python.pip in build.gradle to install Flask.

Suggested build steps:
1. Install Flutter and Android Studio with required SDKs.
2. Copy or replace this folder into your Flutter projects dir.
3. Open android/ folder in Android Studio. Accept Gradle changes, add Chaquopy if prompted.
4. In app/build.gradle, configure chaquopy.python.pip to include 'flask' (or bundle a wheel).
5. Run the app on an emulator/device.

Files of interest:
- android/app/src/main/python/pursuex/  -> your Flask code, templates, static
- lib/main.dart                        -> Flutter app with WebView and splash
- android/app/src/main/java/.../MainActivity.java -> Java code that starts Python via Chaquopy

This setup is non-trivial; if you'd like, I can further:
- Fill chaquopy.python.pip configuration
- Add a Gradle wrapper and more complete Android project files
- Replace placeholder Java code with Kotlin or platform channels for robust startup


Finalized: Chaquopy pip configured for Flask & requests; AndroidManifest and launcher icon added.
Open android/ in Android Studio, resolve Gradle/Chaquopy plugins, and build.
