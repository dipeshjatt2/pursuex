// PursueX JavaScript Application

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize form enhancements
    initializeFormEnhancements();
    
    // Initialize file upload handlers
    initializeFileUploads();
    
    // Initialize clipboard functionality
    initializeClipboard();
    
    // Initialize theme handling
    initializeTheme();
    
    // Initialize progress indicators
    initializeProgress();
    
    // Add loading states to forms
    initializeLoadingStates();
    
    console.log('PursueX application initialized successfully');
}

// Tooltip initialization
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Form enhancements
function initializeFormEnhancements() {
    // Auto-resize textareas
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        // Initial resize
        resizeTextarea(textarea);
        
        // Resize on input
        textarea.addEventListener('input', function() {
            resizeTextarea(this);
        });
        
        // Add character counter for large textareas
        if (textarea.rows >= 6) {
            addCharacterCounter(textarea);
        }
    });
    
    // Form validation feedback
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                showFormErrors(form);
            }
            form.classList.add('was-validated');
        });
    });
    
    // Real-time validation for required fields
    const requiredInputs = document.querySelectorAll('input[required], textarea[required], select[required]');
    requiredInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
    });
}

function resizeTextarea(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 300) + 'px';
}

function addCharacterCounter(textarea) {
    const counter = document.createElement('div');
    counter.className = 'form-text text-end';
    counter.id = textarea.id + '_counter';
    
    const updateCounter = () => {
        const count = textarea.value.length;
        const lines = textarea.value.split('\n').length;
        counter.textContent = `${count} characters, ${lines} lines`;
    };
    
    textarea.parentNode.appendChild(counter);
    textarea.addEventListener('input', updateCounter);
    updateCounter();
}

function validateField(field) {
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    
    if (!field.checkValidity()) {
        field.classList.add('is-invalid');
        if (feedback) {
            feedback.textContent = field.validationMessage;
        }
    } else {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
    }
}

function showFormErrors(form) {
    const firstInvalid = form.querySelector('.is-invalid');
    if (firstInvalid) {
        firstInvalid.focus();
        firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

// File upload enhancements
function initializeFileUploads() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(input => {
        // Style file input
        styleFileInput(input);
        
        // Add drag and drop
        addDragAndDrop(input);
        
        // File validation
        input.addEventListener('change', function() {
            validateFileInput(this);
        });
    });
}

function styleFileInput(input) {
    // Create custom file input display
    const wrapper = document.createElement('div');
    wrapper.className = 'custom-file-input';
    
    const label = document.createElement('label');
    label.className = 'form-label';
    label.innerHTML = '<i class="fas fa-cloud-upload-alt me-2"></i>Choose file or drag here';
    
    const preview = document.createElement('div');
    preview.className = 'file-preview mt-2';
    
    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);
    wrapper.appendChild(label);
    wrapper.appendChild(preview);
    
    input.addEventListener('change', function() {
        updateFilePreview(this, preview);
    });
}

function addDragAndDrop(input) {
    const wrapper = input.closest('.custom-file-input') || input.parentNode;
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        wrapper.addEventListener(eventName, preventDefaults, false);
    });
    
    ['dragenter', 'dragover'].forEach(eventName => {
        wrapper.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        wrapper.addEventListener(eventName, unhighlight, false);
    });
    
    wrapper.addEventListener('drop', function(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (input.multiple) {
            input.files = files;
        } else {
            input.files = files;
        }
        
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }, false);
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    function highlight(e) {
        wrapper.classList.add('drag-over');
    }
    
    function unhighlight(e) {
        wrapper.classList.remove('drag-over');
    }
}

function updateFilePreview(input, preview) {
    preview.innerHTML = '';
    
    if (input.files && input.files.length > 0) {
        Array.from(input.files).forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item d-flex align-items-center mt-2';
            fileItem.innerHTML = `
                <i class="fas fa-file-alt me-2 text-primary"></i>
                <span class="file-name">${file.name}</span>
                <span class="file-size ms-auto text-muted">${formatFileSize(file.size)}</span>
            `;
            preview.appendChild(fileItem);
        });
    }
}

function validateFileInput(input) {
    const maxSize = 16 * 1024 * 1024; // 16MB
    const allowedTypes = ['text/plain', 'text/csv'];
    
    Array.from(input.files).forEach(file => {
        if (file.size > maxSize) {
            showNotification('File too large. Maximum size is 16MB.', 'error');
            input.value = '';
            return;
        }
        
        if (!allowedTypes.includes(file.type) && !file.name.match(/\.(txt|csv)$/i)) {
            showNotification('Invalid file type. Only TXT and CSV files are allowed.', 'error');
            input.value = '';
            return;
        }
    });
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Clipboard functionality
function initializeClipboard() {
    // Add copy buttons to result elements
    const copyableElements = document.querySelectorAll('.copyable, .result-value');
    
    copyableElements.forEach(element => {
        element.style.cursor = 'pointer';
        element.title = 'Click to copy';
        
        element.addEventListener('click', function() {
            copyToClipboard(this.textContent.trim());
        });
    });
    
    // Add copy all button for results
    const resultsContainer = document.querySelector('.results-container');
    if (resultsContainer) {
        addCopyAllButton(resultsContainer);
    }
}

function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function() {
            showNotification('Copied to clipboard!', 'success');
        }).catch(function(err) {
            fallbackCopyTextToClipboard(text);
        });
    } else {
        fallbackCopyTextToClipboard(text);
    }
}

function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.position = 'fixed';
    
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showNotification('Copied to clipboard!', 'success');
    } catch (err) {
        showNotification('Failed to copy to clipboard', 'error');
    }
    
    document.body.removeChild(textArea);
}

function addCopyAllButton(container) {
    const button = document.createElement('button');
    button.className = 'btn btn-outline-secondary btn-sm';
    button.innerHTML = '<i class="fas fa-copy me-1"></i>Copy All Results';
    button.type = 'button';
    
    button.addEventListener('click', function() {
        const allText = Array.from(container.querySelectorAll('.result-value'))
            .map(el => el.textContent.trim())
            .filter(text => text)
            .join('\n');
        
        copyToClipboard(allText);
    });
    
    container.insertBefore(button, container.firstChild);
}

// Theme handling
function initializeTheme() {
    // Check for saved theme preference or default to light
    const savedTheme = localStorage.getItem('pursuex-theme') || 'light';
    applyTheme(savedTheme);
    
    // Theme toggle functionality (if toggle exists)
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = document.body.getAttribute('data-theme') || 'light';
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            applyTheme(newTheme);
            localStorage.setItem('pursuex-theme', newTheme);
        });
    }
}

function applyTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    
    // Update theme toggle icon if exists
    const themeToggle = document.querySelector('.theme-toggle i');
    if (themeToggle) {
        themeToggle.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }
}

// Progress indicators
function initializeProgress() {
    // Add progress bars to forms with file uploads
    const uploadForms = document.querySelectorAll('form[enctype*="multipart"]');
    
    uploadForms.forEach(form => {
        form.addEventListener('submit', function() {
            showProgress();
        });
    });
}

function showProgress() {
    const progressContainer = document.createElement('div');
    progressContainer.className = 'progress-overlay';
    progressContainer.innerHTML = `
        <div class="progress-content">
            <div class="spinner-border text-primary mb-3" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p>Processing your request...</p>
            <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                     role="progressbar" style="width: 0%"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(progressContainer);
    
    // Simulate progress
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        
        const progressBar = progressContainer.querySelector('.progress-bar');
        progressBar.style.width = progress + '%';
        
        if (progress >= 90) {
            clearInterval(interval);
        }
    }, 500);
    
    // Remove on page unload
    window.addEventListener('beforeunload', function() {
        if (progressContainer.parentNode) {
            progressContainer.parentNode.removeChild(progressContainer);
        }
    });
}

// Loading states for forms
function initializeLoadingStates() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                addLoadingState(submitBtn);
            }
        });
    });
}

function addLoadingState(button) {
    const originalText = button.innerHTML;
    const loadingText = button.getAttribute('data-loading-text') || 
                       '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
    
    button.innerHTML = loadingText;
    button.disabled = true;
    
    // Store original state
    button.setAttribute('data-original-text', originalText);
}

function removeLoadingState(button) {
    const originalText = button.getAttribute('data-original-text');
    if (originalText) {
        button.innerHTML = originalText;
        button.disabled = false;
    }
}

// Notification system
function showNotification(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icon = getNotificationIcon(type);
    notification.innerHTML = `
        <i class="${icon} me-2"></i>
        <span>${message}</span>
        <button type="button" class="btn-close" aria-label="Close"></button>
    `;
    
    // Position notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        color: white;
        animation: slideInRight 0.3s ease-out;
        max-width: 400px;
    `;
    
    // Set background color based on type
    const colors = {
        success: '#198754',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#0dcaf0'
    };
    notification.style.backgroundColor = colors[type] || colors.info;
    
    document.body.appendChild(notification);
    
    // Auto remove
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }
    }, duration);
    
    // Close button
    const closeBtn = notification.querySelector('.btn-close');
    closeBtn.addEventListener('click', function() {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    });
}

function getNotificationIcon(type) {
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-triangle',
        warning: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle'
    };
    return icons[type] || icons.info;
}

// Utility functions
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .progress-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    }
    
    .progress-content {
        background: white;
        padding: 2rem;
        border-radius: 0.5rem;
        text-align: center;
        max-width: 400px;
        width: 90%;
    }
    
    .custom-file-input {
        position: relative;
        border: 2px dashed #dee2e6;
        border-radius: 0.5rem;
        padding: 2rem;
        text-align: center;
        transition: all 0.3s ease;
    }
    
    .custom-file-input:hover,
    .custom-file-input.drag-over {
        border-color: #0d6efd;
        background-color: rgba(13, 110, 253, 0.1);
    }
    
    .file-item {
        padding: 0.5rem;
        background-color: rgba(0, 0, 0, 0.05);
        border-radius: 0.25rem;
        margin-top: 0.5rem;
    }
`;
document.head.appendChild(style);

// Export functions for external use
window.PursueX = {
    showNotification,
    copyToClipboard,
    showProgress,
    addLoadingState,
    removeLoadingState,
    debounce,
    throttle
};
