
package com.dipesh.pursuex

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Start Chaquopy Python
        try {
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(this))
            }
            val py = Python.getInstance()
            // Start Flask server in a background thread using your packaged python app
            thread {
                try {
                    // Change working dir to python files location inside app files
                    val os = py.getModule("os")
                    // Note: Chaquopy exposes app's assets; adjust path if needed in Android Studio
                    // Attempt to import and run app factory
                    try {
                        val pursuex = py.getModule("pursuex.app")
                        val app = pursuex.callAttr("create_flask_app")
                        app.callAttr("run", mapOf("host" to "127.0.0.1", "port" to 5000))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Python init error: " + e.message, Toast.LENGTH_LONG).show()
        }

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("http://127.0.0.1:5000")
    }
}
