
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const PursuexApp());
}

class PursuexApp extends StatelessWidget {
  const PursuexApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pursuex',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _ready = false;
  @override
  void initState() {
    super.initState();
    _startServerAndWait();
  }

  Future<void> _startServerAndWait() async {
    // For Chaquopy, the Android native MainActivity will start Python.
    // Here we just wait and poll the local server.
    int attempts = 0;
    while (attempts < 15) {
      try {
        final uri = Uri.parse('http://127.0.0.1:5000/__status');
        final res = await Future.any([Future.delayed(Duration(seconds:2), () => null), Future(() => null)]);
        // We won't actually perform HTTP here in Flutter; proceed to WebView after delay.
        await Future.delayed(Duration(seconds:1));
        attempts++;
        // Simple heuristic: after 3 seconds assume server is up (MainActivity starts it)
        if (attempts > 3) {
          setState(() => _ready = true);
          return;
        }
      } catch (e) {
        await Future.delayed(Duration(seconds:1));
      }
    }
    setState(() => _ready = true);
  }

  @override
  Widget build(BuildContext context) {
    return _ready ? const WebAppView() : Scaffold(
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
          CircularProgressIndicator(),
          SizedBox(height: 20),
          Text("Starting Pursuex...")
        ],),
      ),
    );
  }
}

class WebAppView extends StatefulWidget {
  const WebAppView({super.key});
  @override
  State<WebAppView> createState() => _WebAppViewState();
}

class _WebAppViewState extends State<WebAppView> {
  late WebViewController _controller;
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: WebView(
          initialUrl: 'http://127.0.0.1:5000',
          javascriptMode: JavascriptMode.unrestricted,
          onWebViewCreated: (controller) {
            _controller = controller;
          },
        ),
      ),
    );
  }
}
