#!/bin/bash
# ==============================
# GitHub Auto Upload Script
# Author: Dipesh
# ==============================

# CONFIGURATION
GIT_USER="dipeshjatt2"
REPO_NAME="pursuex"
BRANCH="main"

# ⚠️ Put your Personal Access Token here (classic token with repo scope)
GIT_TOKEN=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

# DIRECTORY where your repo is stored
REPO_DIR="/storage/emulated/0/ps2"

# ==============================
# SCRIPT STARTS
# ==============================
cd "$REPO_DIR" || { echo "❌ Repo directory not found"; exit 1; }

# Mark repo as safe (Termux storage fix)
git config --global --add safe.directory "$REPO_DIR"

# Set remote with token
git remote set-url origin "https://$GIT_USER:$GIT_TOKEN@github.com/$GIT_USER/$REPO_NAME-"

# Add all files
git add .

# Commit with timestamp
git commit -m "Auto-upload on $(date '+%Y-%m-%d %H:%M:%S')"

# Push to GitHub
git push -u origin "$BRANCH"

echo "✅ Upload completed successfully!"
