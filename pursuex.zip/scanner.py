import socket
import requests
import dns.resolver
import threading
import time
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
import ssl
import subprocess
import tempfile
import os

class BugScanXScanner:
    """Main scanner class that implements BugScanX functionality"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'PursueX/1.0 BugScanX Scanner'
        })
    
    def scan_hosts(self, hosts, mode='direct', method='HEAD', timeout=8, follow_redirects=False):
        """Scan hosts for bug host discovery"""
        results = []
        
        def scan_single_host(host):
            try:
                # Clean host input
                host = host.strip()
                if not host:
                    return None
                
                # Add protocol if missing
                if not host.startswith(('http://', 'https://')):
                    host = f'https://{host}'
                
                result = {
                    'host': host,
                    'status': 'unknown',
                    'response_code': None,
                    'response_time': None,
                    'headers': {},
                    'is_bug_host': False,
                    'mode': mode
                }
                
                start_time = time.time()
                
                if mode == 'direct':
                    response = self._direct_scan(host, method, timeout, follow_redirects)
                elif mode == 'directnon302':
                    response = self._directnon302_scan(host, method, timeout)
                elif mode == 'ssl_sni':
                    response = self._ssl_sni_scan(host, timeout)
                elif mode == 'proxy':
                    response = self._proxy_scan(host, timeout)
                else:
                    response = self._direct_scan(host, method, timeout, follow_redirects)
                
                if response:
                    result['status'] = 'success'
                    result['response_code'] = getattr(response, 'status_code', None)
                    result['response_time'] = round((time.time() - start_time) * 1000, 2)
                    result['headers'] = dict(getattr(response, 'headers', {}))
                    result['is_bug_host'] = self._analyze_bug_host(response, mode)
                
                return result
                
            except Exception as e:
                return {
                    'host': host,
                    'status': 'error',
                    'error': str(e),
                    'mode': mode
                }
        
        # Use ThreadPoolExecutor for concurrent scanning
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_host = {executor.submit(scan_single_host, host): host for host in hosts}
            
            for future in as_completed(future_to_host):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def _direct_scan(self, host, method, timeout, follow_redirects):
        """Direct HTTP/HTTPS scan"""
        try:
            response = self.session.request(
                method=method,
                url=host,
                timeout=timeout,
                allow_redirects=follow_redirects,
                verify=False
            )
            return response
        except Exception:
            return None
    
    def _directnon302_scan(self, host, method, timeout):
        """Direct scan excluding redirects"""
        try:
            response = self.session.request(
                method=method,
                url=host,
                timeout=timeout,
                allow_redirects=False,
                verify=False
            )
            # Exclude redirect responses
            if response.status_code in [301, 302, 303, 307, 308]:
                return None
            return response
        except Exception:
            return None
    
    def _ssl_sni_scan(self, host, timeout):
        """SSL/SNI hostname verification"""
        try:
            parsed = urlparse(host)
            hostname = parsed.hostname or parsed.path
            port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((hostname, port), timeout) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    # Create mock response object
                    class MockResponse:
                        def __init__(self):
                            self.status_code = 200
                            self.headers = {'SSL-SNI': 'verified'}
                    
                    return MockResponse()
        except Exception:
            return None
    
    def _proxy_scan(self, host, timeout):
        """Proxy mode with WebSocket upgrade testing"""
        try:
            headers = {
                'Connection': 'Upgrade',
                'Upgrade': 'websocket',
                'Sec-WebSocket-Key': 'dGhlIHNhbXBsZSBub25jZQ==',
                'Sec-WebSocket-Version': '13'
            }
            
            response = self.session.get(
                host,
                headers=headers,
                timeout=timeout,
                verify=False
            )
            return response
        except Exception:
            return None
    
    def _analyze_bug_host(self, response, mode):
        """Analyze if the host is suitable as a bug host"""
        if not response:
            return False
        
        # Check for common bug host indicators
        status_code = getattr(response, 'status_code', 0)
        headers = dict(getattr(response, 'headers', {}))
        
        # Good indicators for bug hosts
        if status_code in [200, 204, 404]:
            return True
        
        # Check for specific headers that indicate tunneling capability
        tunnel_headers = ['upgrade', 'connection', 'proxy-connection']
        for header in tunnel_headers:
            if header in [h.lower() for h in headers.keys()]:
                return True
        
        return False
    
    def scan_subdomains(self, domains):
        """Scan subdomains for SNI bug host analysis"""
        results = []
        
        def scan_domain_subdomains(domain):
            try:
                # Common subdomain prefixes for bug host discovery
                subdomains = ['www', 'cdn', 'api', 'static', 'img', 'assets', 'media', 
                             'm', 'mobile', 'admin', 'dev', 'test', 'staging']
                
                domain_results = []
                for sub in subdomains:
                    subdomain = f"{sub}.{domain}"
                    try:
                        # Try to resolve the subdomain
                        answers = dns.resolver.resolve(subdomain, 'A')
                        if answers:
                            domain_results.append({
                                'subdomain': subdomain,
                                'ip': str(answers[0]),
                                'status': 'active'
                            })
                    except:
                        continue
                
                return {'domain': domain, 'subdomains': domain_results}
            except Exception as e:
                return {'domain': domain, 'error': str(e)}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_domain = {executor.submit(scan_domain_subdomains, domain): domain for domain in domains}
            
            for future in as_completed(future_to_domain):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def scan_ips(self, ips):
        """Analyze specific IPs for potential SNI bug hosts"""
        results = []
        
        def scan_single_ip(ip):
            try:
                result = {
                    'ip': ip,
                    'ports': [],
                    'reverse_dns': None,
                    'status': 'unknown'
                }
                
                # Reverse DNS lookup
                try:
                    result['reverse_dns'] = socket.gethostbyaddr(ip)[0]
                except:
                    pass
                
                # Scan common ports
                common_ports = [80, 443, 8080, 8443]
                for port in common_ports:
                    try:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(3)
                        if sock.connect_ex((ip, port)) == 0:
                            result['ports'].append(port)
                        sock.close()
                    except:
                        pass
                
                result['status'] = 'scanned'
                return result
                
            except Exception as e:
                return {'ip': ip, 'error': str(e)}
        
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_ip = {executor.submit(scan_single_ip, ip): ip for ip in ips}
            
            for future in as_completed(future_to_ip):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def find_subdomains(self, domain):
        """Find subdomains using multiple discovery sources"""
        results = {
            'domain': domain,
            'subdomains': [],
            'sources': []
        }
        
        try:
            # Method 1: Common subdomain bruteforce
            common_subs = [
                'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
                'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'ns3', 'm', 'test',
                'blog', 'dev', 'www2', 'admin', 'forum', 'news', 'vpn', 'ns4', 'mail2',
                'new', 'mysql', 'old', 'lists', 'support', 'mobile', 'mx', 'static',
                'docs', 'beta', 'shop', 'sql', 'secure', 'demo', 'cp', 'calendar'
            ]
            
            found_subdomains = []
            for sub in common_subs:
                subdomain = f"{sub}.{domain}"
                try:
                    answers = dns.resolver.resolve(subdomain, 'A')
                    if answers:
                        found_subdomains.append({
                            'subdomain': subdomain,
                            'ip': str(answers[0]),
                            'source': 'bruteforce'
                        })
                except:
                    continue
            
            results['subdomains'] = found_subdomains
            results['sources'].append('DNS Bruteforce')
            
        except Exception as e:
            results['error'] = str(e)
        
        return results
    
    def find_same_ip_domains(self, target):
        """Find other domains hosted on the same IP"""
        results = {
            'target': target,
            'ip': None,
            'domains': [],
            'status': 'unknown'
        }
        
        try:
            # Get IP address
            if self._is_ip(target):
                ip = target
            else:
                ip = socket.gethostbyname(target)
            
            results['ip'] = ip
            
            # Reverse DNS lookup
            try:
                reverse_dns = socket.gethostbyaddr(ip)[0]
                results['domains'].append({
                    'domain': reverse_dns,
                    'source': 'reverse_dns'
                })
            except:
                pass
            
            results['status'] = 'completed'
            
        except Exception as e:
            results['error'] = str(e)
        
        return results
    
    def process_txt_files(self, files, operation):
        """Process TXT files with various operations"""
        results = {
            'operation': operation,
            'processed_files': [],
            'output': [],
            'status': 'success'
        }
        
        try:
            all_lines = []
            
            # Read all files
            for file in files:
                if file and file.filename:
                    content = file.read().decode('utf-8')
                    lines = [line.strip() for line in content.split('\n') if line.strip()]
                    all_lines.extend(lines)
                    results['processed_files'].append(file.filename)
            
            if operation == 'merge':
                results['output'] = all_lines
            elif operation == 'deduplicate':
                results['output'] = list(set(all_lines))
            elif operation == 'clean':
                # Remove invalid domains/IPs
                cleaned = []
                for line in all_lines:
                    if self._is_valid_host(line):
                        cleaned.append(line)
                results['output'] = cleaned
            elif operation == 'split':
                # Split into chunks of 100
                chunk_size = 100
                chunks = [all_lines[i:i + chunk_size] for i in range(0, len(all_lines), chunk_size)]
                results['output'] = chunks
            
        except Exception as e:
            results['status'] = 'error'
            results['error'] = str(e)
        
        return results
    
    def scan_ports(self, hosts, ports):
        """Scan open ports on hosts"""
        results = []
        
        def scan_host_ports(host):
            try:
                # Extract hostname/IP
                if host.startswith(('http://', 'https://')):
                    parsed = urlparse(host)
                    hostname = parsed.hostname
                else:
                    hostname = host
                
                host_result = {
                    'host': hostname,
                    'open_ports': [],
                    'closed_ports': [],
                    'status': 'scanned'
                }
                
                for port in ports:
                    try:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(3)
                        if sock.connect_ex((hostname, port)) == 0:
                            host_result['open_ports'].append(port)
                        else:
                            host_result['closed_ports'].append(port)
                        sock.close()
                    except:
                        host_result['closed_ports'].append(port)
                
                return host_result
                
            except Exception as e:
                return {'host': host, 'error': str(e)}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_host = {executor.submit(scan_host_ports, host): host for host in hosts}
            
            for future in as_completed(future_to_host):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def get_dns_records(self, domains):
        """Get comprehensive DNS records"""
        results = []
        
        def get_domain_records(domain):
            try:
                domain_result = {
                    'domain': domain,
                    'records': {},
                    'status': 'success'
                }
                
                record_types = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS']
                
                for record_type in record_types:
                    try:
                        answers = dns.resolver.resolve(domain, record_type)
                        domain_result['records'][record_type] = [str(answer) for answer in answers]
                    except:
                        domain_result['records'][record_type] = []
                
                return domain_result
                
            except Exception as e:
                return {'domain': domain, 'error': str(e)}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_domain = {executor.submit(get_domain_records, domain): domain for domain in domains}
            
            for future in as_completed(future_to_domain):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def perform_osint(self, hosts):
        """Perform OSINT analysis on hosts"""
        results = []
        
        def analyze_host(host):
            try:
                analysis = {
                    'host': host,
                    'ip': None,
                    'location': None,
                    'isp': None,
                    'ports': [],
                    'headers': {},
                    'technologies': [],
                    'status': 'analyzed'
                }
                
                # Get IP
                try:
                    if not self._is_ip(host):
                        hostname = host.replace('http://', '').replace('https://', '').split('/')[0]
                        analysis['ip'] = socket.gethostbyname(hostname)
                    else:
                        analysis['ip'] = host
                except:
                    pass
                
                # Try to get HTTP headers
                try:
                    if not host.startswith(('http://', 'https://')):
                        host = f'https://{host}'
                    
                    response = requests.get(host, timeout=5, verify=False)
                    analysis['headers'] = dict(response.headers)
                    
                    # Detect technologies from headers
                    server = response.headers.get('Server', '')
                    if server:
                        analysis['technologies'].append(server)
                    
                    powered_by = response.headers.get('X-Powered-By', '')
                    if powered_by:
                        analysis['technologies'].append(powered_by)
                        
                except:
                    pass
                
                return analysis
                
            except Exception as e:
                return {'host': host, 'error': str(e)}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_host = {executor.submit(analyze_host, host): host for host in hosts}
            
            for future in as_completed(future_to_host):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def _is_ip(self, address):
        """Check if address is an IP"""
        try:
            socket.inet_aton(address)
            return True
        except socket.error:
            return False
    
    def _is_valid_host(self, host):
        """Check if host is valid domain or IP"""
        if not host:
            return False
        
        # Clean the host
        host = host.replace('http://', '').replace('https://', '').split('/')[0]
        
        # Check if IP
        if self._is_ip(host):
            return True
        
        # Check if valid domain
        domain_pattern = re.compile(
            r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$'
        )
        return bool(domain_pattern.match(host))
