import os
import json
import csv
import io
from flask import send_file, make_response
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {'txt', 'csv'}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_hosts_input(hosts_text, uploaded_file):
    """Process hosts from text input or uploaded file"""
    hosts = []
    
    # Process text input
    if hosts_text:
        hosts.extend([line.strip() for line in hosts_text.split('\n') if line.strip()])
    
    # Process uploaded file
    if uploaded_file and uploaded_file.filename and allowed_file(uploaded_file.filename):
        try:
            content = uploaded_file.read().decode('utf-8')
            hosts.extend([line.strip() for line in content.split('\n') if line.strip()])
        except Exception:
            pass
    
    # Remove duplicates while preserving order
    seen = set()
    unique_hosts = []
    for host in hosts:
        if host not in seen:
            seen.add(host)
            unique_hosts.append(host)
    
    return unique_hosts

def save_results_file(results_data, format):
    """Save results to file in specified format"""
    try:
        data = results_data['data']
        tool_type = results_data['type']
        timestamp = results_data['timestamp']
        
        filename = f"pursuex_{tool_type}_{timestamp.replace(':', '-')}.{format}"
        
        if format == 'txt':
            output = io.StringIO()
            
            # Format data as text
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        output.write(f"=== {item.get('host', item.get('domain', item.get('ip', 'Item')))} ===\n")
                        for key, value in item.items():
                            if key not in ['host', 'domain', 'ip']:
                                output.write(f"{key}: {value}\n")
                        output.write("\n")
                    else:
                        output.write(f"{item}\n")
            
            response = make_response(output.getvalue())
            response.headers['Content-Type'] = 'text/plain'
            response.headers['Content-Disposition'] = f'attachment; filename={filename}'
            return response
            
        elif format == 'json':
            response = make_response(json.dumps(data, indent=2))
            response.headers['Content-Type'] = 'application/json'
            response.headers['Content-Disposition'] = f'attachment; filename={filename}'
            return response
            
        elif format == 'csv':
            output = io.StringIO()
            
            if isinstance(data, list) and data:
                # Flatten nested dictionaries for CSV
                flattened_data = []
                for item in data:
                    if isinstance(item, dict):
                        flat_item = {}
                        for key, value in item.items():
                            if isinstance(value, dict):
                                for sub_key, sub_value in value.items():
                                    flat_item[f"{key}_{sub_key}"] = sub_value
                            elif isinstance(value, list):
                                flat_item[key] = ', '.join(map(str, value))
                            else:
                                flat_item[key] = value
                        flattened_data.append(flat_item)
                
                if flattened_data:
                    fieldnames = list(flattened_data[0].keys())
                    writer = csv.DictWriter(output, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(flattened_data)
            
            response = make_response(output.getvalue())
            response.headers['Content-Type'] = 'text/csv'
            response.headers['Content-Disposition'] = f'attachment; filename={filename}'
            return response
            
    except Exception as e:
        raise Exception(f"Failed to save file: {str(e)}")
