from flask import render_template, request, redirect, url_for, flash, jsonify, send_file, session
from werkzeug.utils import secure_filename
import os
import json
import csv
import io
import tempfile
from datetime import datetime
from app import app
from scanner import BugScanXScanner
from utils import allowed_file, process_hosts_input, save_results_file

scanner = BugScanXScanner()

@app.route('/')
def index():
    """Main dashboard with all tools"""
    return render_template('index.html')

@app.route('/host-checker', methods=['GET', 'POST'])
def host_checker():
    """Host Checker tool with all modes"""
    if request.method == 'POST':
        # Get form data
        hosts_text = request.form.get('hosts', '').strip()
        uploaded_file = request.files.get('hosts_file')
        mode = request.form.get('mode', 'direct')
        http_method = request.form.get('http_method', 'HEAD')
        timeout = int(request.form.get('timeout', 8))
        follow_redirects = 'follow_redirects' in request.form
        
        # Process hosts input
        hosts = process_hosts_input(hosts_text, uploaded_file)
        
        if not hosts:
            flash('Please provide hosts to scan', 'error')
            return render_template('host_checker.html')
        
        # Perform scan
        try:
            results = scanner.scan_hosts(
                hosts=hosts,
                mode=mode,
                method=http_method,
                timeout=timeout,
                follow_redirects=follow_redirects
            )
            
            # Store results in session for download
            session['last_results'] = {
                'type': 'host_checker',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='Host Checker',
                                 scan_params={
                                     'mode': mode,
                                     'method': http_method,
                                     'timeout': timeout,
                                     'follow_redirects': follow_redirects,
                                     'total_hosts': len(hosts)
                                 })
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('host_checker.html')
    
    return render_template('host_checker.html')

@app.route('/subdomain-scanner', methods=['GET', 'POST'])
def subdomain_scanner():
    """Subdomain Scanner tool"""
    if request.method == 'POST':
        domains_text = request.form.get('domains', '').strip()
        uploaded_file = request.files.get('domains_file')
        
        domains = process_hosts_input(domains_text, uploaded_file)
        
        if not domains:
            flash('Please provide domains to scan', 'error')
            return render_template('subdomain_scanner.html')
        
        try:
            results = scanner.scan_subdomains(domains)
            
            session['last_results'] = {
                'type': 'subdomain_scanner',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='Subdomain Scanner',
                                 scan_params={'total_domains': len(domains)})
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('subdomain_scanner.html')
    
    return render_template('subdomain_scanner.html')

@app.route('/ip-scanner', methods=['GET', 'POST'])
def ip_scanner():
    """IP Addresses Scanner tool"""
    if request.method == 'POST':
        ips_text = request.form.get('ips', '').strip()
        uploaded_file = request.files.get('ips_file')
        
        ips = process_hosts_input(ips_text, uploaded_file)
        
        if not ips:
            flash('Please provide IP addresses to scan', 'error')
            return render_template('ip_scanner.html')
        
        try:
            results = scanner.scan_ips(ips)
            
            session['last_results'] = {
                'type': 'ip_scanner',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='IP Scanner',
                                 scan_params={'total_ips': len(ips)})
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('ip_scanner.html')
    
    return render_template('ip_scanner.html')

@app.route('/subdomain-finder', methods=['GET', 'POST'])
def subdomain_finder():
    """Subdomain Finder tool"""
    if request.method == 'POST':
        domain = request.form.get('domain', '').strip()
        
        if not domain:
            flash('Please provide a domain to find subdomains', 'error')
            return render_template('subdomain_finder.html')
        
        try:
            results = scanner.find_subdomains(domain)
            
            session['last_results'] = {
                'type': 'subdomain_finder',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='Subdomain Finder',
                                 scan_params={'domain': domain})
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('subdomain_finder.html')
    
    return render_template('subdomain_finder.html')

@app.route('/same-ip-domains', methods=['GET', 'POST'])
def same_ip_domains():
    """Domains Hosted on Same IP tool"""
    if request.method == 'POST':
        target = request.form.get('target', '').strip()
        
        if not target:
            flash('Please provide a domain or IP address', 'error')
            return render_template('same_ip_domains.html')
        
        try:
            results = scanner.find_same_ip_domains(target)
            
            session['last_results'] = {
                'type': 'same_ip_domains',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='Same IP Domains',
                                 scan_params={'target': target})
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('same_ip_domains.html')
    
    return render_template('same_ip_domains.html')

@app.route('/txt-toolkit', methods=['GET', 'POST'])
def txt_toolkit():
    """TXT Toolkit for file operations"""
    if request.method == 'POST':
        operation = request.form.get('operation')
        uploaded_files = request.files.getlist('files')
        
        if not uploaded_files or not any(f.filename for f in uploaded_files):
            flash('Please upload files for processing', 'error')
            return render_template('txt_toolkit.html')
        
        try:
            results = scanner.process_txt_files(uploaded_files, operation)
            
            session['last_results'] = {
                'type': 'txt_toolkit',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='TXT Toolkit',
                                 scan_params={'operation': operation})
        except Exception as e:
            flash(f'Processing failed: {str(e)}', 'error')
            return render_template('txt_toolkit.html')
    
    return render_template('txt_toolkit.html')

@app.route('/port-checker', methods=['GET', 'POST'])
def port_checker():
    """Open Port Checker tool"""
    if request.method == 'POST':
        hosts_text = request.form.get('hosts', '').strip()
        uploaded_file = request.files.get('hosts_file')
        custom_ports = request.form.get('custom_ports', '').strip()
        
        hosts = process_hosts_input(hosts_text, uploaded_file)
        
        if not hosts:
            flash('Please provide hosts to scan', 'error')
            return render_template('port_checker.html')
        
        try:
            # Default ports for tunneling
            ports = [80, 443, 8080, 8443, 3128, 8888, 9090]
            if custom_ports:
                custom_port_list = [int(p.strip()) for p in custom_ports.split(',') if p.strip().isdigit()]
                ports.extend(custom_port_list)
            
            results = scanner.scan_ports(hosts, ports)
            
            session['last_results'] = {
                'type': 'port_checker',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='Port Checker',
                                 scan_params={'total_hosts': len(hosts), 'ports': ports})
        except Exception as e:
            flash(f'Scan failed: {str(e)}', 'error')
            return render_template('port_checker.html')
    
    return render_template('port_checker.html')

@app.route('/dns-records', methods=['GET', 'POST'])
def dns_records():
    """DNS Records tool"""
    if request.method == 'POST':
        domains_text = request.form.get('domains', '').strip()
        uploaded_file = request.files.get('domains_file')
        
        domains = process_hosts_input(domains_text, uploaded_file)
        
        if not domains:
            flash('Please provide domains to query', 'error')
            return render_template('dns_records.html')
        
        try:
            results = scanner.get_dns_records(domains)
            
            session['last_results'] = {
                'type': 'dns_records',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='DNS Records',
                                 scan_params={'total_domains': len(domains)})
        except Exception as e:
            flash(f'Query failed: {str(e)}', 'error')
            return render_template('dns_records.html')
    
    return render_template('dns_records.html')

@app.route('/host-osint', methods=['GET', 'POST'])
def host_osint():
    """HOST OSINT tool"""
    if request.method == 'POST':
        hosts_text = request.form.get('hosts', '').strip()
        uploaded_file = request.files.get('hosts_file')
        
        hosts = process_hosts_input(hosts_text, uploaded_file)
        
        if not hosts:
            flash('Please provide hosts for OSINT analysis', 'error')
            return render_template('host_osint.html')
        
        try:
            results = scanner.perform_osint(hosts)
            
            session['last_results'] = {
                'type': 'host_osint',
                'data': results,
                'timestamp': datetime.now().isoformat()
            }
            
            return render_template('results.html', 
                                 results=results, 
                                 tool_name='HOST OSINT',
                                 scan_params={'total_hosts': len(hosts)})
        except Exception as e:
            flash(f'OSINT analysis failed: {str(e)}', 'error')
            return render_template('host_osint.html')
    
    return render_template('host_osint.html')

@app.route('/download-results/<format>')
def download_results(format):
    """Download results in specified format"""
    if 'last_results' not in session:
        flash('No results available for download', 'error')
        return redirect(url_for('index'))
    
    results_data = session['last_results']
    
    try:
        if format == 'txt':
            return save_results_file(results_data, 'txt')
        elif format == 'json':
            return save_results_file(results_data, 'json')
        elif format == 'csv':
            return save_results_file(results_data, 'csv')
        else:
            flash('Invalid format requested', 'error')
            return redirect(url_for('index'))
    except Exception as e:
        flash(f'Download failed: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.errorhandler(404)
def not_found_error(error):
    return render_template('base.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('base.html'), 500
